<div class="form-group">
    <?php echo Form::label('Category','Categoria:'); ?>

    <?php echo Form::select('category_id',$categories, null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Name','Nome:'); ?>

    <?php echo Form::text('name',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Description','Descricao:'); ?>

    <?php echo Form::textarea('description',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Price','Preco:'); ?>

    <?php echo Form::textarea('price',null, ['class'=>'form-control']); ?>

</div>