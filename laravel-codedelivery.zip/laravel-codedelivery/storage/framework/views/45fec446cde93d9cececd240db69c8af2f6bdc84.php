<!-- Extende o app.blade.php e a se��o content de app.blade.php para o index.blade.php -->


        <?php $__env->startSection('content'); ?>


    <div class="container">
        <h3>Nova Categoria</h3>

        <?php echo $__env->make('errors._check', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::open(['route'=>'admin.categories.store','class'=>'form']); ?>


        <!-- Puxa o formulado _form.blade.php -->
        <?php echo $__env->make('admin.categories._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="form-group">
            <?php echo Form::submit('Criar Categoria',['class'=>'btn btn-primary']); ?>

        </div>



        <?php echo Form::close(); ?>






    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>