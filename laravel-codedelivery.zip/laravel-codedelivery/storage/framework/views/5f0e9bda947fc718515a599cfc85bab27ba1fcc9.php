<!-- Extende o app.blade.php e a se��o content de app.blade.php para o index.blade.php -->


        <?php $__env->startSection('content'); ?>


    <div class="container">
        <h3>Editando cliente: <?php echo e($client->user->name); ?></h3>

        <?php echo $__env->make('errors._check', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <?php echo Form::model($client, ['route'=>['admin.clients.update', $client->id]]); ?>


        <!-- Name Form Input -->

            <?php echo $__env->make('admin.clients._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        <div class="form-group">
            <?php echo Form::submit('Salvar',['class'=>'btn btn-primary']); ?>

        </div>



        <?php echo Form::close(); ?>






    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>