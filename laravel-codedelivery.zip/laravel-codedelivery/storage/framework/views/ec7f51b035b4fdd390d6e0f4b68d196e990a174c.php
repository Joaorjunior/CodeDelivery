<!-- Name Form Input -->

<div class="form-group">
    <?php echo Form::label('Name','Nome:'); ?>

    <?php echo Form::text('name',null, ['class'=>'form-control']); ?>

</div>