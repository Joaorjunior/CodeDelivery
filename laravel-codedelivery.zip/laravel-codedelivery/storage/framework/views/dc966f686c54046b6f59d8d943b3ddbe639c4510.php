<?php $__env->startSection('content'); ?>

    <div class="container">
        <h3> Meus pedidos </h3>

        <a href=" <?php echo e(route('customer.order.create')); ?> " class="btn btn-default"> Novo pedido </a>
    <br><br>


        <table class="table table-bordered">
            <thead>
            <tr>
                <th> ID </th>
                <th> Total </th>
                <th> Status </th>
            </tr>
            </thead>
            <tbody>
            <?php foreach($orders as $order): ?>
                <tr>
                    <td> <?php echo e($order->id); ?> </td>
                    <td><?php echo e($order->total); ?> </td>
                    <td><?php echo e($order->status); ?> </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php echo $orders->render(); ?>




    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>