<!-- Name Form Input -->

<div class="form-group">
    <?php echo Form::label('Name','Nome:'); ?>

    <?php echo Form::text('user[name]',null, ['class'=>'form-control']); ?> <!-- name, faz de conta como se tivesse uma coluna name na tabela de Client, mas n � nessa tabela que o name esta -->
</div>

<div class="form-group">
    <?php echo Form::label('Email','Email:'); ?>

    <?php echo Form::text('user[email]',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Telefone','Telefone:'); ?>

    <?php echo Form::text('phone',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Endere�o','Endere�o:'); ?>

    <?php echo Form::textarea('address',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Cidade','Cidade:'); ?>

    <?php echo Form::text('city',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Estado','Estado:'); ?>

    <?php echo Form::text('state',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('CE','CEP:'); ?>

    <?php echo Form::text('zipcode',null, ['class'=>'form-control']); ?>

</div>