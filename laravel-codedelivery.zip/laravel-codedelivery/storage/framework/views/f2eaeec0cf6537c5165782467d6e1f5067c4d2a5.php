<div class="form-group">
    <?php echo Form::label('Codigo','Codigo:'); ?>

    <?php echo Form::text('code',null, ['class'=>'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Valor','Valor:'); ?>

    <?php echo Form::text('value',null, ['class'=>'form-control']); ?>

</div>