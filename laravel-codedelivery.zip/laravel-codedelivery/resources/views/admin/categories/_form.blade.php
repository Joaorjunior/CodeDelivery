<!-- Name Form Input -->

<div class="form-group">
    {!! Form::label('Name','Nome:') !!}
    {!! Form::text('name',null, ['class'=>'form-control']) !!}
</div>