<div class="form-group">
    {!! Form::label('Codigo','Codigo:') !!}
    {!! Form::text('code',null, ['class'=>'form-control']) !!}
</div>

<div class="form-group">
    {!! Form::label('Valor','Valor:') !!}
    {!! Form::text('value',null, ['class'=>'form-control']) !!}
</div>